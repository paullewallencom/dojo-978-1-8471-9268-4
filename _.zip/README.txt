1) Move the directory so that it lieas parallel with dojox, dijit, dojo, et.c.
2) Make sure that you have a PHP-capable webserver 
3) To run examples using Ajax and dojo.data, make sure that the root of the dojo director (containing this directory and dojo, dijit, dojox, et.c.) is called /dojodev, or possibly rename urls in the examples to fit your environment,


